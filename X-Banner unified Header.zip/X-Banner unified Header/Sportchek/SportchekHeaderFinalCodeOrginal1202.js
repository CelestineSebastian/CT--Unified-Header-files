window.optimizely = window.optimizely || [];

  var utils = window.optimizely.get('utils');

  var init = function($) {

utils.waitForElement('.page-header__content.container').then(function() {

utils.waitForElement('ul.page-nav__list.page-nav__list_full').then(function() {


$(".utility-nav").prepend('<a href="#" class="my-account-mobile utility-nav__link">SignIn/Register</a>');
$('<div id="overlay"></div>').prependTo("body");

$(document).on("click",".my-account-mobile.utility-nav__link",function(){

$("div#header-account-button .header-account__placeholder.drawer-ui__toggle").click();
$("#overlay").addClass("displayBlock");
$("button.menu-toggle").click();
setTimeout(function(){

if ( $("section.header-account__sign-in .close-signin").length < 1 ) {

$("section.header-account__sign-in").prepend('<a class="close-signin">X</a>');
}

 }, 2000);
});

$(document).on("click","a.close-signin",function(){

$("div#header-account-button").removeClass("active");
$("div#overlay").removeClass("displayBlock");
});


$(document).on("click","div#overlay",function(){


$(this).removeClass("displayBlock");

});

});

utils.waitForElement('a.account-menu__link').then(function() {

$(document).on("click",'a.account-menu__link',function(){
location.reload();
});
});



$(".header-account__trigger,button.mfp-close,input.sign-up-message-form__submit.button").click(function(){


console.log("timer clicked");
var clearAccount = setInterval(myTimer, 1000);


function myTimer(){
console.log("timer started");

var str = $("span#headerPickupStoreName").text();
var res = str.match(/Choose now/g);

if ( res != null ) {
  $("span#headerPickupStoreName").text("Choose a Store");
}
if ( $(".header-account.drawer-ui").hasClass("logged-in") == true) {

  $("div#header-account-button .header-account__trigger .header-account__text").text('My Account');
  $(".my-account-mobile").text('My Account');
  clearInterval(clearAccount);
}
else if ( $(".header-account.drawer-ui").hasClass("logged-in") == false ){
  $("div#header-account-button .header-account__trigger .header-account__text").text('Sign In/Register');
  $(".my-account-mobile").text('Sign In/Register');
  clearInterval(clearAccount);
}

}

$(document).click(function (e)
{
    var container = $("div#sign-in");  // Add an elemet to target

    if (!container.is(e.target) && container.has(e.target).length === 0)
    {
        
        myTimer();
    }
});


});


  
  $('<div class="header-search-mobile"><div class="header-search-mobile-image"></div><span>Search</span></div><div class="header-triangle"><a href="https://www.sportchek.ca/campaigns/triangle-loyalty.html"><img src="https://marks.scene7.com/is/image/marksp/tri-icon"><span> Triangle Rewards</span></a></div>').appendTo(".page-header__content.container");
  $('<div class="header-store-hours-new"></div>').prependTo("a.header-pickup-store__link-container");
  $('<img class="header-cart-new" src="https://marks.scene7.com/is/image/marksp/cart-icon"></img>').insertBefore('span.header-cart__text');
  $('<a href="/" class="header-logo__image_mobile">Sport Chek</a>').insertBefore('a.header-logo__image');

  $(".header-search").addClass("displayNone");

        
        $  (document).on("click",".header-myaccount a",function(){

            $("a.header-account__trigger").click();

        });


function storeName(){
var str = $("span#headerPickupStoreName").text();
var res = str.match(/Choose now/g);

if ( res != null ) {
  $("span#headerPickupStoreName").text("Choose a Store");
   $(".header-store-hours-new").addClass("displayNone");
   $("a.header-pickup-store__link-container").addClass("specialLeftSpace");
   $("span#headerPickupStoreTitle").addClass("displayNone");
}

else if ( res == null  ) {
 $(".header-store-hours-new").removeClass("displayNone");
$("a.header-pickup-store__link-container").removeClass("specialLeftSpace");
$("span#headerPickupStoreTitle").addClass("displayNone");


}
}
utils.waitForElement('span#headerPickupStoreName').then(function() {
setTimeout(function(){
  storeName();
 }, 2000);
});
/*
  if ( $("span#headerPickupStoreName").text().length && $("span#headerPickupStoreTitle").hasClass("displayNone") == false ){
  $("span#headerPickupStoreTitle").addClass("displayNone");

  }
*/


/* Start cookie process for store hours */

function getCookie(cname,cvalue) {
  var name = cname + "=";
  var decodedCookie = decodeURIComponent(document.cookie);
  var ca = decodedCookie.split(';');
  for(var i = 0; i <ca.length; i++) {
    var c = ca[i];
    while (c.charAt(0) == ' ') {
      c = c.substring(1);
    }
    if (c.indexOf(name) == 0) {
      return c.substring(name.length, c.length);
    }
  }
  return "";
}

$(document).on("click","a.header-pickup-store__link-container,button.button.pickup-store-list__set-button",function(){

$("span#headerPickupStoreTitle").addClass("displayNone");
            setTimeout(function(){
                                  // Start to retrieve store hours
                                         var selectedStore = $("span#headerPickupStoreName").text();
                                      var hours;
                                      var str;
                                      var storeTitle;
                                      $("ul.pickup-store-list li").each(function(){
                                      storeTitle = $(this).find("span.pickup-store-list__title").text();
                                      if ( selectedStore == storeTitle ) {
                                      var x = $(this).find(".pickup-store__working-hours ul li");
                                      var today = new Date();
                                      var day = today.getDay();
                                     
                                      switch(day) {
                                          case 1: str = x["0"]["innerText"]; break;
                                          case 2: str = x["1"]["innerText"]; break;
                                          case 3: str = x["2"]["innerText"]; break;
                                          case 4: str = x["3"]["innerText"]; break;
                                          case 5: str = x["4"]["innerText"]; break;
                                          case 6: str = x["5"]["innerText"]; break;
                                          case 7: str = x["6"]["innerText"]; break;
                                             }
                                          var s = str.match(/^(\S+)\s(.*)/).slice(1);
                                         hours = s[1];
                                          $(".header-store-hours-new").text(hours);
                                         
                                                 function createCookie(name,value,path) {
                                                    var expires = "";
                                                    var date = new Date();
                                                    var midnight = new Date(date.getFullYear(), date.getMonth(), date.getDate(), 23, 59, 59);
                                                    expires = "; expires=" + midnight.toGMTString();
                                                    if (!path) {
                                                      path = "/";
                                                    }
                                                    document.cookie = name + "=" + value + expires + "; path=" + path;
                                                  }
                                                
                                                createCookie('newStoreHours', hours);
                                         //$.cookie('newStoreHours', hours);
                                      }
                                      });
                                      }, 2000);
                                  // End to retrieve store hours

                        setTimeout(function(){
                        storeName();
                        }, 2000);
                          
                     
                     
 });


utils.waitForElement('span#headerPickupStoreName').then(function() {
  function storeHourseSet(){
               var checkStoreHoursValueLoad = getCookie('newStoreHours');
               var str = $("span#headerPickupStoreName").text();
               var res = str.match(/Choose now/g);
               var res1 = str.match(/Choose a Store/g);
               if ( (res == null) || (res1 == null) ){
              $(".header-store-hours-new").text(checkStoreHoursValueLoad);
            }
  }
      setTimeout(function(){
storeHourseSet();
}, 3000);
});
  /* End cookie process for store hours */ 
    
    
    
    
    
  });
    
/* Search bar exposed by default on homepage */

function headerSearchImage(){

var headerSearch =  $(".header-search");

      if ( $(".header-search").hasClass("displayNone") == true ) {
      console.log("had displayNone");
      $(headerSearch).removeClass("displayNone");
      $(".header-search-mobile-image").addClass("newSearchImage");
      }

      else {
        console.log("had displayBlock");
      $(headerSearch).addClass("displayNone");
      $(".header-search-mobile-image").removeClass("newSearchImage");
      }

}


if($(window).width() < 600) {


utils.waitForElement('.header-search').then(function() {


  if ( location.href == "https://www.sportchek.ca/" ) {

  headerSearchImage();
  console.log("width < 600 activated");

  }

});
}

/* End of search bar exposed by default on homepage */
$(document).on("click",".header-search-mobile",function(){

headerSearchImage();
});


utils.waitForElement('div#header-account-button .header-account__trigger').then(function() {

if ( $(".header-account.drawer-ui").hasClass("logged-in") == true) {

  $("div#header-account-button .header-account__trigger .header-account__text").text('My Account');
}
else {
  $("div#header-account-button .header-account__trigger .header-account__text").text('Sign In/Register');
}


  });
  

$(window).scroll(function() {
  setTimeout(function(){
var specialCase = $(".page-nav-container__center.container");

if ( ( $(".page-nav-wrap").hasClass("page-header_folded") == true ) && ($(specialCase).hasClass("specialClass") == false ) ){

$(specialCase).addClass("specialClass");

}
else if ( $(".page-nav-wrap").hasClass("page-header_folded") == false ){

$(".page-nav-container__center.container").removeClass("specialClass");
}
}, 1000);
});

$(".header-cart.drawer-ui.drawer-ui_state_dropdown").mouseover(function() {

$("div#header-account-button").removeClass("active");

});

$("button.menu-toggle").on("click",function(){
if ($(".header-search").hasClass("displayNone") == false ) {
$(".header-search").addClass("displayNone");
$(".header-search-mobile-image").removeClass("newSearchImage");
}
});

  };

// Wait for jquery to load first
var waitForjQueryPlaceholder = setInterval(function() {
  if (window.jQuery) {
    clearInterval(waitForjQueryPlaceholder);
    init(jQuery);
  }
}, 50);
