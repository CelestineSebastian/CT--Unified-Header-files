
window.optimizely = window.optimizely || [];

  var utils = window.optimizely.get('utils');

  var init = function($) {


utils.waitForElement('.choose-a-store a#choose-a-store__button').then(function() {

$(".choose-a-store a#choose-a-store__button").append('<div class="store-hours"></div>');




var str = $("a#choose-a-store__button").text();
var res = str.match(/Choose a store/g);

if ( res != null ) {
  $(".store-hours").addClass("displayNone");
}

else if ( res == null  ) {
$(".store-hours").removeClass("displayNone");

}

});




/* sign In */
utils.waitForElement('.header-sign-in.header-sign-in_en .header-sign-in__label').then(function() {



function myTimer(){
  setTimeout(function(){

var signValue = $(".header-sign-in.header-sign-in_en .header-sign-in__label");
if ( $(signValue).text() == "Sign in") {

  $(signValue).html('<span class="my-account">Sign In/Register</span>');
 $(signValue).addClass("signInNew");
}

else if ( $(signValue).text() == "My Account"){

  $(signValue).html('<span class="my-account">My Account</span>');
  $(signValue).removeClass("signInNew");
}
}, 2000);
}
myTimer();

$(document).on("click",".modal__content.register,button.modal__close,section.modal__container,a.account-menu__link",function(){
console.log("logout clicked");
myTimer();
});


$("button.modal__close").click(function(){

location.reload();
});

});
/* End of Sign In */

function storeName(){
var str = $("a#choose-a-store__button").text();;
var res = str.match(/Choose a store/g);
if ( res != null ) {

   $(".choose-a-store").addClass("specialLeftSpace");
}
else if ( res == null  ) {

$(".choose-a-store").removeClass("specialLeftSpace");
}
}
utils.waitForElement('a#choose-a-store__button').then(function() {
setTimeout(function(){
  storeName();
 }, 2000);
});

utils.waitForElement('.header-main__search-tool-label.header-main__search-tool-label_active').then(function() { 


$(document).on("click",".header-main__search-tool-label.header-main__search-tool-label_active",function(){
var headerSearch =  $(".header-main__search-tool-label.header-main__search-tool-label_active");
var headerExpandedClass = $(".header-main.header-main_static");

if ( $(headerExpandedClass).hasClass("header-main__wrapper--expanded") == true ) {
  console.log("true");
$(headerSearch).addClass("newSearchImage");
$("header.page-header").addClass("specialHeight");
}
else {
$(headerSearch).removeClass("newSearchImage");
$("header.page-header").removeClass("specialHeight");
}

});




$(".header-main__search-tool-label.header-main__search-tool-label_active").addClass("newSearchImage");

});
utils.waitForElement('.header-main .container').then(function() {

$('<div class="header-triangle"><a href="https://www.marks.com/en/triangle.html"><img src="https://marks.scene7.com/is/image/marksp/tri-icon"><span> Triangle Rewards</span></a></div>').insertBefore(".header-utility__sign-in");


$("span.header-cart__text").text('Cart');





/* Start cookie process for store hours */

function getCookie(cname,cvalue) {
  var name = cname + "=";
  var decodedCookie = decodeURIComponent(document.cookie);
  var ca = decodedCookie.split(';');
  for(var i = 0; i <ca.length; i++) {
    var c = ca[i];
    while (c.charAt(0) == ' ') {
      c = c.substring(1);
    }
    if (c.indexOf(name) == 0) {
      return c.substring(name.length, c.length);
    }
  }
  return "";
}

$(document).on("click","a#choose-a-store__button,button.choose-a-store-search__button,.choose-a-store-locations__item-select-button",function(){
              
               if ( $(".choose-a-store a#choose-a-store__button .store-hours").length < 1 ){
                                    $(".choose-a-store a#choose-a-store__button").append('<div class="store-hours"></div>');
                                  }

              setTimeout(function(){
              storeName();
              }, 2000);
            setTimeout(function(){
                                  // Start to retrieve store hours
                                  if ( $(".choose-a-store a#choose-a-store__button .store-hours").length < 1 ){
                                    $(".choose-a-store a#choose-a-store__button").append('<div class="store-hours"></div>');
                                  }
                                     
                                      var selectedStore = $("a#choose-a-store__button").text();
                                      var hours;
                                      var str;
                                      var storeTitle;
                                      $(".choose-a-store-locations__item-list li").each(function(){
                                      storeTitle = $(this).find("span.choose-a-store-locations__item-title_name").text();
                                      if ( selectedStore == storeTitle ) {
                                    
                                       
                                      var today = new Date();
                                      var day = today.getDay();
                                       var x = $(this).find("ul.working-hours__list li");
                                 
                                      switch(day) {
                                          case 0: str = x["0"]["innerText"]; break;
                                          case 1: str = x["1"]["innerText"]; break;
                                          case 2: str = x["2"]["innerText"]; break;
                                          case 3: str = x["3"]["innerText"]; break;
                                          case 4: str = x["4"]["innerText"]; break;
                                          case 5: str = x["5"]["innerText"]; break;
                                          case 6: str = x["6"]["innerText"]; break;
                                             }

                                         var s = str.replace(/[A-Z][a-z][a-z]+/gi, "");
                                         
                                         hours = s;
                                       console.log("hours"+ hours);
                                          $(".store-hours").text(hours);
                                         

                                         function createCookie(name,value,path) {
                                                    var expires = "";
                                                    var date = new Date();
                                                    var midnight = new Date(date.getFullYear(), date.getMonth(), date.getDate(), 23, 59, 59);
                                                    expires = "; expires=" + midnight.toGMTString();
                                                    if (!path) {
                                                      path = "/";
                                                    }
                                                    document.cookie = name + "=" + value + expires + "; path=" + path;
                                                  }
                                                
                                                createCookie('newStoreHoursMarks', hours);

                          
                                      }
                                      });
                                      }, 2000);
                                  // End to retrieve store hours
                     
                     
 });



  function storeHourseSet(){
               var checkStoreHoursValueLoad = getCookie('newStoreHoursMarks');
              $(".store-hours").text(checkStoreHoursValueLoad);
  }
  setTimeout(function(){
  storeHourseSet();
  }, 2000);
  /* End cookie process for store hours */ 
});
};
// Wait for jquery to load first
var waitForjQueryPlaceholder = setInterval(function() {
  if (window.jQuery) {
    clearInterval(waitForjQueryPlaceholder);
    init(jQuery);
  }
}, 50);


